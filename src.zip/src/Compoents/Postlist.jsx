import { useState } from "react";
import Post  from "./Post";
import classes from "./Postlists.module.css";
import NewPost from "./NewPost";
import Modal from "./Modal";

function Postlist({isPosting , onStopPosting})
{
    
    const [posts,setPosts]=useState([]);

    function addPostHandler(postData){
        setPosts((existingPosts)=>[postData, ...existingPosts]);
    }
    return(
        <>
        {isPosting ? 
               (<Modal onClose={onStopPosting}>
               <NewPost
 
                onCancel={onStopPosting}
                onAddPost={addPostHandler}
                />
               </Modal>)
            : false}
 
  
        <ul className={classes.posts}>
                {posts.map((post)=> <Post key={post.body} author={post.author}  body={posts.body}/>)}
    <Post author="Gone" body="angular is awesome too"/>
        </ul>
        </>

    );
}

export default Postlist;