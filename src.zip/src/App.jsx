import MainHeader from "./Compoents/MainHeader";
import Postlist from "./Compoents/Postlist";
import { useState } from "react";

function App() {
  const [modalisvisible, setmodalIsVisible]=useState(false);

  function hidemodalhandler(){
      setmodalIsVisible(false);
  }

  function showmodelhandler(){
    setmodalIsVisible(true);
  }
  return (
    <>
      <MainHeader onCreatePost={showmodelhandler}/>
      <main>
        <Postlist isPosting={modalisvisible} onStopPosting={hidemodalhandler}/>
      </main>
    </>

  );

}

export default App;
